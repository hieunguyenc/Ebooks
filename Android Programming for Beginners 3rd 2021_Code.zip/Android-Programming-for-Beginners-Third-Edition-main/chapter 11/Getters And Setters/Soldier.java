package com.packtpub.gettersandsetters.app;

public class Soldier{
    private int health;
    public int getHealth(){
        return health;
    }

    public void setHealth(int newHealth){
        health = newHealth;
    }
}

